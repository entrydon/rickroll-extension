chrome.runtime.onInstalled.addListener(() => {
  console.log("Rick Me 확장프로그램 설치됨");
});

chrome.action.onClicked.addListener((tab) => {
  console.log("릭롤 탭 여는 중...");
  chrome.tabs.create({
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  });
});
